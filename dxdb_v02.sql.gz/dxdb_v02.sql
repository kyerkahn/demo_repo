-- phpMyAdmin SQL Dump
-- version 3.3.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 15, 2011 at 02:00 PM
-- Server version: 5.1.54
-- PHP Version: 5.3.5-1ubuntu7.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dxdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `Docs`
--

CREATE TABLE IF NOT EXISTS `Docs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `comment` varchar(100) DEFAULT NULL,
  `status` enum('discussion','insight','draft','archive') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `Docs`
--

INSERT INTO `Docs` (`id`, `title`, `comment`, `status`, `created_at`, `updated_at`) VALUES
(1, 'hello... bitch', 'Helen for Kenn', 'discussion', '2011-07-15 13:47:42', '2011-07-15 13:47:42'),
(2, 'pi=3.14', 'helen for samantha', 'insight', '2011-07-15 13:52:31', '2011-07-15 13:52:31'),
(3, 'e=mc^2', 'To kenn, helen, ann', 'discussion', '2011-07-15 13:54:04', '2011-07-15 13:54:04'),
(4, 'kenn loves you all =)', 'delivers to all users <3', 'archive', '2011-07-15 13:58:12', '2011-07-15 13:58:12');

-- --------------------------------------------------------

--
-- Table structure for table `DocsUsers`
--

CREATE TABLE IF NOT EXISTS `DocsUsers` (
  `doc_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `DocsUsers`
--

INSERT INTO `DocsUsers` (`doc_id`, `user_id`) VALUES
(1, 2),
(2, 4),
(3, 2),
(3, 3),
(3, 5),
(4, 1),
(4, 2),
(4, 3),
(4, 4),
(4, 5),
(4, 6);

-- --------------------------------------------------------

--
-- Table structure for table `Files`
--

CREATE TABLE IF NOT EXISTS `Files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(100) NOT NULL,
  `guid` varchar(40) NOT NULL,
  `doc_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `Files`
--

INSERT INTO `Files` (`id`, `filename`, `guid`, `doc_id`) VALUES
(1, 'aginor.jpg', '4e200cbe4ef67', 1),
(2, 'Eva_v13c84-012.png', '4e200cbe4ff93', 1),
(3, 'graendal_aol.jpg', '4e200ddf2abb1', 2),
(4, 'graendal_wot.jpg', '4e200ddf2b9e8', 2),
(5, 'ishamael_aol.jpg', '4e200e3c54ffd', 3),
(6, 'WoT-EOTW_0_01.jpg', '4e200f344ce0c', 4),
(7, 'WoT-EOTW_0_02.jpg', '4e200f344dc7f', 4);

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE IF NOT EXISTS `Users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `role` enum('admin','superior','employee','client') NOT NULL,
  `hashed_pass` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`id`, `username`, `role`, `hashed_pass`) VALUES
(1, 'admin', 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997'),
(2, 'kenn', 'client', '40bd001563085fc35165329ea1ff5c5ecbdbbeef'),
(3, 'helen', 'employee', '40bd001563085fc35165329ea1ff5c5ecbdbbeef'),
(4, 'samantha', 'superior', '40bd001563085fc35165329ea1ff5c5ecbdbbeef'),
(5, 'ann', 'employee', '40bd001563085fc35165329ea1ff5c5ecbdbbeef'),
(6, 'cindy', 'client', '40bd001563085fc35165329ea1ff5c5ecbdbbeef');
