-- phpMyAdmin SQL Dump
-- version 3.3.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 11, 2011 at 01:00 PM
-- Server version: 5.1.54
-- PHP Version: 5.3.5-1ubuntu7.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dxdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `Docs`
--

CREATE TABLE IF NOT EXISTS `Docs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `comment` varchar(100) DEFAULT NULL,
  `status` enum('discussion','insight','draft','archive') NOT NULL,
  `role` enum('admin','superior','employee','client') NOT NULL,
  `filename` varchar(100) NOT NULL,
  `guid` varchar(40) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `Docs`
--

INSERT INTO `Docs` (`id`, `title`, `comment`, `status`, `role`, `filename`, `guid`, `created_at`, `updated_at`) VALUES
(1, 'Doc1', 'Comment1', 'draft', 'superior', 'Eva_v13c84-012.png', '4e1a8f8d2dcdc', '2011-07-11 09:48:54', '2011-07-11 09:52:13'),
(2, 'Title2', '', 'discussion', 'client', 'Eva_v13c84-013-014.png', '4e1a90a29271a', '2011-07-11 09:56:50', '2011-07-11 09:56:50'),
(3, 'ololo', 'dfja;sdkjf', 'draft', 'employee', 'Eva_v13c84-015.png', '4e1aa8d10404c', '2011-07-11 11:40:00', '2011-07-11 11:40:00'),
(4, 'to be or not', 'to be', 'archive', 'employee', 'Eva_v13c84-017.png', '4e1aa907ce765', '2011-07-11 11:40:55', '2011-07-11 11:40:55'),
(6, 'docdoc', 'doc', 'discussion', 'employee', 'Eva_v13c84-018.png', '4e1aaf42bc6b4', '2011-07-11 12:07:30', '2011-07-11 12:07:30'),
(7, 'nge', 'forever', 'insight', 'employee', 'Eva_v13c84-019.png', '4e1aaf6dc8ff3', '2011-07-11 12:08:13', '2011-07-11 12:08:13'),
(8, 'aska', '<3', 'draft', 'employee', 'Eva_v13c84-024.png', '4e1aaf981fcce', '2011-07-11 12:08:56', '2011-07-11 12:08:56'),
(9, 'oxoxo', '', 'discussion', 'employee', 'Eva_v13c84-025.png', '4e1aafb8278c4', '2011-07-11 12:09:28', '2011-07-11 12:09:28'),
(10, 'fffff', 'ff', 'discussion', 'employee', 'seamas19.jpg', '4e1ab0a204b17', '2011-07-11 12:13:21', '2011-07-11 12:13:21'),
(11, 'wot', '', 'draft', 'employee', 'seamas_cover1.jpg', '4e1ab0b4b5c9f', '2011-07-11 12:13:40', '2011-07-11 12:13:40'),
(12, 'eye of the', 'world', 'archive', 'employee', 'seamas_cover2.jpg', '4e1ab0daed13a', '2011-07-11 12:14:18', '2011-07-11 12:14:18'),
(13, 'tom', '', 'draft', 'employee', 'seamas_cover4.jpg', '4e1ab0f7a280e', '2011-07-11 12:14:47', '2011-07-11 12:14:47'),
(14, 'dsfasdf', '', 'archive', 'employee', 'seamas_cover5.jpg', '4e1ab113a049d', '2011-07-11 12:15:15', '2011-07-11 12:15:15'),
(15, 'uno', '', 'insight', 'employee', 'uno_final.jpg', '4e1ab12f32cc5', '2011-07-11 12:15:43', '2011-07-11 12:15:43'),
(16, 'doc for client', '', 'discussion', 'client', 'seamas_cover6.jpg', '4e1ab781bfb9f', '2011-07-11 12:42:41', '2011-07-11 12:42:41'),
(17, 'doc from client', 'jpeg', 'insight', 'superior', 'aginor.jpg', '4e1ab96a10bf3', '2011-07-11 12:50:50', '2011-07-11 12:50:50');

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE IF NOT EXISTS `Users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `role` enum('admin','superior','employee','client') NOT NULL,
  `hashed_pass` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`id`, `username`, `role`, `hashed_pass`) VALUES
(1, 'admin', 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997'),
(2, 'kenn', 'client', '40bd001563085fc35165329ea1ff5c5ecbdbbeef'),
(3, 'helen', 'employee', '40bd001563085fc35165329ea1ff5c5ecbdbbeef'),
(4, 'samantha', 'superior', '40bd001563085fc35165329ea1ff5c5ecbdbbeef'),
(5, 'ann', 'employee', '40bd001563085fc35165329ea1ff5c5ecbdbbeef'),
(6, 'cindy', 'client', '40bd001563085fc35165329ea1ff5c5ecbdbbeef');
